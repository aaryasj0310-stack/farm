"""Pure-python price math mirroring the engine exactly (no numpy)."""
import math

from config import MARKET_I0, MARKET_PARAMS, PRICE_FLOOR, WHEAT_BUY_PRICE_BUFFER


def _shape(func, x, T):
    x = max(0.0, x)
    if func == "linear":
        return x
    if func == "sq":
        return x * x
    if func == "sqrt":
        return math.sqrt(x)
    if func == "log":
        return math.log(1.0 + x)
    if func == "log10":
        return math.log10(1.0 + x)
    if func == "hinge":
        if not T or T <= 0:
            return x
        u = x / T
        return u + 8.0 * max(0.0, u - 1.0) ** 2
    return x


def amplitude(item, side):
    p = MARKET_PARAMS[item]
    f = p["bf"] if side == "below" else p["af"]
    target = p["bt"] if side == "below" else p["at"]
    return target * p["base"] / _shape(f, p["T"], p["T"])


def market_price(item, inventory):
    """Engine-exact sell quote."""
    p = MARKET_PARAMS[item]
    base, I0, T = p["base"], MARKET_I0, p["T"]
    inv = float(inventory)
    if inv < I0:
        f = p["bf"]
        amp = p["bt"] * base / _shape(f, T, T)
        price = base + amp * _shape(f, I0 - inv, T)
    else:
        f = p["af"]
        amp = p["at"] * base / _shape(f, T, T)
        price = base - amp * _shape(f, inv - I0, T)
    return max(PRICE_FLOOR, int(round(price)))


def estimate_wheat_buy_price(market_or_ctx=None, default_price=25.0) -> float:
    """Return the authoritative buffered unit purchase price for WHEAT.

    Quotes WHEAT at current observed market inventory and applies WHEAT_BUY_PRICE_BUFFER.
    """
    if market_or_ctx is not None:
        inv = None
        if isinstance(market_or_ctx, dict):
            if "market" in market_or_ctx and isinstance(market_or_ctx["market"], dict):
                inv = market_or_ctx["market"].get("inventory", {}).get("WHEAT")
            elif "inventory" in market_or_ctx and isinstance(market_or_ctx["inventory"], dict):
                inv = market_or_ctx["inventory"].get("WHEAT")
        elif hasattr(market_or_ctx, "market"):
            m = getattr(market_or_ctx, "market")
            if hasattr(m, "inventory"):
                inv = getattr(m.inventory, "WHEAT", None) or (m.inventory.get("WHEAT") if isinstance(m.inventory, dict) else None)
        if inv is not None:
            raw_px = market_price("WHEAT", inv)
            return float(math.ceil(raw_px * WHEAT_BUY_PRICE_BUFFER))
    return float(math.ceil(default_price * WHEAT_BUY_PRICE_BUFFER))


def _solve_shape(func, y, T):
    """Solve _shape(func, x) == y for x >= 0 (y >= 0)."""
    if func == "linear":
        return y
    if func == "sq":
        return math.sqrt(y)
    if func == "sqrt":
        return y * y
    if func == "log":
        return math.expm1(y)
    if func == "log10":
        return 10.0 ** y - 1.0
    if func == "hinge":
        if y <= 1.0:
            return y * T
        u = (15.0 + math.sqrt(32.0 * y - 31.0)) / 16.0
        return u * T
    raise ValueError(func)


def inventory_for_price_at_least(item, min_price):
    """Max units that can be ADDED above I0 while the quote stays >= min_price.

    Returns the glut-side crossing inventory; (level - I0) is the dump budget.
    """
    p = MARKET_PARAMS[item]
    target = max(float(min_price), PRICE_FLOOR + 1)  # strictly above floor
    if target >= p["base"]:
        return float(MARKET_I0)
    y = (p["base"] - target) / amplitude(item, "above")
    return MARKET_I0 + _solve_shape(p["af"], y, p["T"])


def inventory_at_price(item, target_price):
    """Exact continuous inverse of market_price (both branches).

    Scarcity targets (< base) return inventory BELOW I0; glut targets
    (> base) return inventory ABOVE I0; base returns I0. Targets below the
    $1 floor are clamped to the floor crossing. Used to convert a forecast
    price path into the implied underlying inventory path.
    """
    p = MARKET_PARAMS[item]
    base = p["base"]
    target = max(float(target_price), PRICE_FLOOR)
    if abs(target - base) < 1e-12:
        return float(MARKET_I0)
    if target > base:
        y = (target - base) / amplitude(item, "below")
        return float(MARKET_I0 - _solve_shape(p["bf"], y, p["T"]))
    y = (base - target) / amplitude(item, "above")
    return float(MARKET_I0 + _solve_shape(p["af"], y, p["T"]))


def safe_drip_budget(item, current_inventory, keep_frac, spot=None):
    """Largest Q whose LAST unit still quotes >= keep_frac * spot.

    Uses exact continuous inverse and verifies discrete integer quote across
    both scarcity and glut branches.
    """
    if spot is None:
        spot = market_price(item, current_inventory)
    if spot <= PRICE_FLOOR:
        return 0
    threshold = max(PRICE_FLOOR + 1, int(spot * keep_frac))
    limit = inventory_at_price(item, threshold)
    budget = max(0, int(limit - float(current_inventory)))
    while budget > 0 and market_price(item, current_inventory + budget) < threshold:
        budget -= 1
    while market_price(item, current_inventory + budget + 1) >= threshold:
        budget += 1
    return max(0, budget)


def drip_batch_size(item, current_inventory, keep_frac):
    """Largest Q whose LAST unit still quotes >= keep_frac * spot.

    Uses a coarse-to-fine search on the continuous inverse; cheap and exact
    enough for slicing decisions.
    """
    spot = market_price(item, current_inventory)
    budget = safe_drip_budget(item, current_inventory, keep_frac, spot)
    return budget, spot


def total_revenue_estimate(item, start_inventory, quantity):
    """TR of dumping `quantity` units one-at-a-time from start_inventory.

    Respects the $1-floor freeze: units sold at $1 don't shift inventory.
    """
    inv = float(start_inventory)
    total = 0
    for _ in range(int(quantity)):
        px = market_price(item, inv)
        total += px
        if px > PRICE_FLOOR:
            inv += 1.0
    return total


def optimal_dump_quantity(item, start_inventory, min_acceptable):
    """Q* before the marginal quote drops below min_acceptable."""
    inv = float(start_inventory)
    q = 0
    while True:
        px = market_price(item, inv)
        if px < min_acceptable:
            return q
        q += 1
        if px > PRICE_FLOOR:
            inv += 1.0
        else:  # at floor the quote never recovers by adding more
            return q
