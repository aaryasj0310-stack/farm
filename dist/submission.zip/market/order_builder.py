"""W-market 1/3: MacroPlanner intents -> valid engine market orders.

Engine semantics honored (kaggriculture.py):
  - max `maxMarketOrdersPerTurn` (10) orders; extras silently dropped
  - HIRE hires exactly ONE hand per order entry, cost fib(hires_today)
  - BUY_LAND costs LAND_PRICES[len(unlocked)-1]; no-op if locked none left
  - BUY_SEED / BUY_ANIMAL: fixed per-unit cost; animals land in the SHED
    and both obey shedCapacity at commit time
  - BUY_PRODUCT only WHEAT/FERTILIZER; quoted at post-buy inventory so the
    effective price drifts UP while buying -> we budget with a buffer
  - any failed commit aborts that order; ordering the queue by priority
    therefore acts as a graceful degradation mechanism

Budget rule: total estimated spend <= money - reserve. Tiers are filled in
priority order and count-based tiers are clamped to what remains affordable.
"""
import os

from config import (
    ANIMALS,
    CROPS,
    LAND_ORDER,
    LAND_PRICES,
    MAX_MARKET_ORDERS,
    MIN_HANDS_BASE,
    MONEY_RESERVE_DEFAULT,
    WHEAT_BUY_PRICE_BUFFER,
    C4_LIVESTOCK_CUTOFF_DAY,
)
from market.price_math import market_price, estimate_wheat_buy_price


def _fib(n):
    a, b = 1, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def hire_total_cost(k_hands, mult=1):
    """Coins for k hires made today (fib(0)+...+fib(k-1))."""
    return sum(_fib(i) for i in range(k_hands)) * mult


# Priority tiers (lower = executed earlier when order slots / cash run short).
TIER_HIRES = 0
TIER_FEED_WHEAT = 1        # Unavoidable survival feed
TIER_LAND = 2              # Land expansion
TIER_OPTIONAL_WHEAT = 3    # Optional feed buffering (up to 20 days)
TIER_SEEDS = 4             # Seed planting
TIER_ANIMALS = 5           # Livestock purchases


class OrderBuilder:
    def __init__(self, money_reserve=MONEY_RESERVE_DEFAULT):
        self.reserve = money_reserve

    def reinvest_livestock(self, ctx, intents, max_slots=MAX_MARKET_ORDERS):
        """Invest harvest proceeds while there is still time to place animals.

        Recomputed planner intents count animals in transit and reserve future
        wages. Retain normal affordability, housing and shed checks without
        repeating morning hires.
        """
        try:
            from config import SELECTIVE_LIVESTOCK_GATE_ENABLED, SELECTIVE_LIVESTOCK_MAX_DAY
        except ImportError:
            SELECTIVE_LIVESTOCK_GATE_ENABLED = False
            SELECTIVE_LIVESTOCK_MAX_DAY = 14

        allow_reinvest = (ctx["day"] < C4_LIVESTOCK_CUTOFF_DAY) or (
            SELECTIVE_LIVESTOCK_GATE_ENABLED and ctx["day"] <= SELECTIVE_LIVESTOCK_MAX_DAY
        )
        if (not allow_reinvest
                or not 2 <= ctx["hour"] <= 18
                or not intents.get("buy_animal")):
            return [], {}

        # Post-cutoff selective livestock: strictly require physically built, empty, unreserved housing.
        # Queued/planned structures, positive candidates, or dynamic capacity never authorize purchases.
        if ctx["day"] >= C4_LIVESTOCK_CUTOFF_DAY:
            farm = ctx.get("farm")
            private = ctx.get("private")

            def _pasture_free(t):
                t_kind = t.get("kind") if isinstance(t, dict) else getattr(t, "kind", "")
                t_anim = t.get("is_animal") if isinstance(t, dict) else getattr(t, "is_animal", False)
                if t_kind != "PASTURE" or t_anim:
                    return False
                if hasattr(farm, "unlocked") and hasattr(farm, "quadrant_of"):
                    t_pos = tuple(t.get("pos")) if isinstance(t, dict) else tuple(t.pos)
                    return farm.quadrant_of(t_pos) in farm.unlocked
                return True

            physical_empty_pastures = sum(1 for t in farm.iter_tiles() if _pasture_free(t)) if farm else 0

            shed_large = 0
            carried_large = 0
            if private:
                if hasattr(private, "shed") and isinstance(private.shed, dict):
                    shed_large = sum(int(private.shed.get(a, 0)) for a in ("COW", "SHEEP"))
                if hasattr(private, "inventories") and isinstance(private.inventories, list):
                    for inv in private.inventories:
                        if isinstance(inv, dict):
                            carried_large += sum(int(inv.get(a, 0)) for a in ("COW", "SHEEP"))

            pending_large = shed_large + carried_large
            guaranteed_empty = max(0, physical_empty_pastures - pending_large)

            if guaranteed_empty <= 0:
                money = float(getattr(farm, "money", 0)) if farm else 0.0
                return [], {
                    "budget": max(0.0, money - self.reserve),
                    "queued": [],
                    "dropped": [{"kind": "animal", "reason": "no_empty_structure"}],
                    "orders": [],
                }

            capped_buy_animal = {}
            remaining_guaranteed = guaranteed_empty
            trimmed_animals = []
            for a, count in intents.get("buy_animal", {}).items():
                cnt = int(count)
                if cnt <= 0:
                    continue
                if a in ("COW", "SHEEP"):
                    alloc = min(cnt, remaining_guaranteed)
                    if alloc > 0:
                        capped_buy_animal[a] = alloc
                        remaining_guaranteed -= alloc
                    if alloc < cnt:
                        trimmed_animals.append({"kind": "animal", "animal": a, "trimmed_from": cnt, "to": alloc})
                else:
                    capped_buy_animal[a] = cnt

            if not any(v > 0 for v in capped_buy_animal.values()):
                money = float(getattr(farm, "money", 0)) if farm else 0.0
                return [], {
                    "budget": max(0.0, money - self.reserve),
                    "queued": [],
                    "dropped": [{"kind": "animal", "reason": "no_empty_structure"}],
                    "orders": [],
                }

            orders, ledger = self.build(ctx, {
                "buy_animal": capped_buy_animal,
                "buy_wheat": intents.get("buy_wheat", 0),
                "pending_structures": {},
            }, max_slots=max_slots)

            if isinstance(ledger, dict) and "dropped" in ledger:
                ledger["dropped"].extend(trimmed_animals)
            return orders, ledger

        return self.build(ctx, {
            "buy_animal": intents.get("buy_animal", {}),
            "buy_wheat": intents.get("buy_wheat", 0),
            "pending_structures": intents.get("pending_structures", {}),
        }, max_slots=max_slots)

    def build_intraday(self, ctx, intents, max_slots=MAX_MARKET_ORDERS):
        """Intraday market turn order compilation (hours 2-18).

        Evaluates strictly in authoritative priority tier order:
        1. survival / mandatory debt (survival feed wheat)
        2. committed hires / feed / seeds (incremental seed demand)
        3. safely profitable SW land (BUY_LAND if authorized)
        4. discretionary livestock reinvestment (with SW shadow capital protection)

        Does not repeat morning hires (hire=0).
        """
        # Determine permitted livestock under housing checks
        capped_animal = intents.get("buy_animal", {})
        if ctx["day"] >= C4_LIVESTOCK_CUTOFF_DAY:
            _anim_orders, _anim_ledger = self.reinvest_livestock(ctx, intents, max_slots=max_slots)
            if _anim_ledger and "queued" in _anim_ledger and isinstance(_anim_ledger["queued"], dict):
                capped_animal = _anim_ledger["queued"].get("animal", {})
            else:
                capped_animal = {}

        intents_intraday = {
            "hire": 0,
            "buy_wheat": intents.get("buy_wheat", 0),
            "protected_feed_wheat": intents.get("protected_feed_wheat", 0),
            "optional_feed_wheat": intents.get("optional_feed_wheat", 0),
            "buy_land": bool(intents.get("buy_land", False)),
            "buy_seed": intents.get("buy_seed", {}),
            "buy_animal": capped_animal,
            "pending_structures": intents.get("pending_structures", {}),
        }
        return self.build(ctx, intents_intraday, max_slots=max_slots)

    # ------------------------------------------------------------------
    def build(self, ctx, intents, max_slots=MAX_MARKET_ORDERS):
        """intents: MacroPlan.intents dict. Returns (orders, ledger).
        
        Mandatory hire budgeting:
          - Mandatory hires calculate exact hire cost first and reserve that amount.
          - Never let land/seeds/animals/non-survival purchases consume reserved hire money.
          - Survival feed wheat is budgeted before discretionary spending.
          - Discretionary purchases (land, seeds, animals) only draw from remaining discretionary budget.
          - Orders are emitted strictly in priority tier order (hires first, then survival wheat, then land, seeds, animals).
        """
        farm = ctx["farm"]
        money = float(farm.money)
        budget = max(0.0, money - self.reserve)

        inv = {p: float(v) for p, v in ctx["market"].inventory.items()}
        wheat_px = market_price("WHEAT", inv.get("WHEAT", 10000))
        unit_wheat_px = estimate_wheat_buy_price(ctx)
        remaining_shed_room = max(0, 100 - sum(ctx["private"].shed.values())) if ctx.get("private") and hasattr(ctx["private"], "shed") else 100

        # ---- 1. Mandatory hires: exact cost calculated and reserved first ----
        k = int(intents.get("hire", 0))
        start_hires = getattr(farm, "hires_today", 0)
        hire_cost = 0.0
        affordable_hires = 0
        for i in range(k):
            c = float(_fib(start_hires + i))
            if hire_cost + c <= money:
                hire_cost += c
                affordable_hires += 1
            else:
                break
        mandatory_hire_budget = hire_cost

        # ---- 2. Survival feed wheat: reserved before discretionary spending ----
        available_for_purchases = max(0.0, money - mandatory_hire_budget - self.reserve)
        w_req = int(intents.get("buy_wheat", 0))
        if "protected_feed_wheat" in intents:
            w_protected_req = max(0, int(intents["protected_feed_wheat"]))
        else:
            w_protected_req = w_req
        w_optional_req = max(0, w_req - w_protected_req)

        w_protected_buyable = 0
        if w_protected_req > 0 and unit_wheat_px > 0:
            w_protected_buyable = min(w_protected_req, int(available_for_purchases // unit_wheat_px), remaining_shed_room)
        protected_feed_budget = float(w_protected_buyable * unit_wheat_px)
        survival_feed_budget = protected_feed_budget
        remaining_shed_room = max(0, remaining_shed_room - w_protected_buyable)

        # ---- 3. Discretionary budget: land, optional feed buffer, seeds, animals ----
        discretionary_budget = max(0.0, available_for_purchases - protected_feed_budget)

        ledger = {
            "budget": round(budget, 2),
            "mandatory_hire_budget": round(mandatory_hire_budget, 2),
            "survival_feed_budget": round(protected_feed_budget, 2),
            "protected_feed_budget": round(protected_feed_budget, 2),
            "optional_feed_budget": 0.0,
            "w_protected_buyable": w_protected_buyable,
            "w_opt_buyable": 0,
            "w_buyable": w_protected_buyable,
            "discretionary_budget": round(discretionary_budget, 2),
            "spent_estimate": 0.0,
            "queued": [],
            "dropped": [],
            "orders": [],
        }

        if affordable_hires < k:
            ledger["dropped"].append({
                "kind": "hire_budget",
                "requested": k,
                "affordable": affordable_hires,
            })

        if w_protected_req > w_protected_buyable:
            if w_protected_buyable > 0:
                ledger["dropped"].append({
                    "kind": "wheat_protected",
                    "trimmed_from": w_protected_req,
                    "to": w_protected_buyable,
                })
            else:
                reason = "shed_full" if remaining_shed_room == 0 and int(available_for_purchases // unit_wheat_px) > 0 else "budget"
                ledger["dropped"].append({"kind": "wheat_protected", "reason": reason})

        # Collect tiers
        kept = []
        if affordable_hires > 0:
            kept.append((TIER_HIRES, "hire", {"count": affordable_hires}, mandatory_hire_budget))

        if w_protected_buyable > 0:
            kept.append((TIER_FEED_WHEAT, "wheat_protected", {"n": w_protected_buyable, "is_protected": True}, protected_feed_budget))

        remaining_discretionary = discretionary_budget

        # Discretionary Tier: Land (protected feed outranks land, but land outranks optional feed buffer)
        n_extra = len(farm.unlocked) - 1
        if intents.get("buy_land") and n_extra < len(LAND_ORDER):
            land_price = float(LAND_PRICES[n_extra])
            if land_price <= remaining_discretionary + 1e-9:
                kept.append((TIER_LAND, "land", {}, land_price))
                remaining_discretionary -= land_price
            else:
                ledger["dropped"].append({"kind": "land", "reason": "budget"})

        # Discretionary Tier: Optional Feed Wheat (routine buffer)
        w_opt_buyable = 0
        if w_optional_req > 0 and unit_wheat_px > 0:
            w_opt_buyable = min(w_optional_req, int(remaining_discretionary // unit_wheat_px), remaining_shed_room)
        optional_feed_budget = float(w_opt_buyable * unit_wheat_px)
        remaining_shed_room = max(0, remaining_shed_room - w_opt_buyable)
        remaining_discretionary -= optional_feed_budget

        ledger["optional_feed_budget"] = round(optional_feed_budget, 2)
        ledger["w_opt_buyable"] = w_opt_buyable
        ledger["w_buyable"] = w_protected_buyable + w_opt_buyable

        if w_optional_req > w_opt_buyable:
            if w_opt_buyable > 0:
                ledger["dropped"].append({
                    "kind": "wheat_optional",
                    "trimmed_from": w_optional_req,
                    "to": w_opt_buyable,
                })
            else:
                reason = "shed_full" if remaining_shed_room == 0 and int(remaining_discretionary // unit_wheat_px) > 0 else "budget"
                ledger["dropped"].append({"kind": "wheat_optional", "reason": reason})

        if w_opt_buyable > 0:
            kept.append((TIER_OPTIONAL_WHEAT, "wheat_optional", {"n": w_opt_buyable, "is_protected": False}, optional_feed_budget))

        # Discretionary Tier: Seeds
        for crop, n in sorted(intents.get("buy_seed", {}).items()):
            n = int(n)
            if n > 0 and crop in CROPS:
                unit = CROPS[crop]["seed"]
                n_max = int(remaining_discretionary // unit)
                if n_max >= n:
                    kept.append((TIER_SEEDS, "seed", {"crop": crop, "n": n}, float(unit * n)))
                    remaining_discretionary -= unit * n
                elif n_max > 0:
                    kept.append((TIER_SEEDS, "seed", {"crop": crop, "n": n_max}, float(unit * n_max)))
                    remaining_discretionary -= unit * n_max
                    ledger["dropped"].append({
                        "kind": "seed", "crop": crop,
                        "trimmed_from": n, "to": n_max,
                    })
                else:
                    ledger["dropped"].append({"kind": "seed", "crop": crop, "reason": "budget"})

        # Discretionary Tier: Animals
        # Near-term SW protection: protect SW land capital ($2000) from discretionary animals
        # ONLY when SW is currently affordable or conservatively reachable near-term.
        sw_shadow_reserve = 0.0
        discretionary_livestock_suppressed = False
        try:
            from config import SW_OWNERSHIP_MODE, LAND_BUY_LAST_DAY
            use_experiment_sw = (SW_OWNERSHIP_MODE in ("early_liquidity", "pure_economic"))
        except Exception:
            use_experiment_sw = False
            LAND_BUY_LAST_DAY = 18

        if use_experiment_sw and "SW" not in farm.unlocked and not any(t[1] == "land" for t in kept) and 7 <= ctx.get("day", 0) <= LAND_BUY_LAST_DAY:
            try:
                from strategy.expansion_planner import compute_conservative_inflows_before_hire
                inflows_24h = compute_conservative_inflows_before_hire(farm, ctx.get("private"))
            except Exception:
                inflows_24h = 0.0
            near_term_obligations = mandatory_hire_budget + survival_feed_budget + self.reserve
            if (money + inflows_24h) >= 2000.0 + near_term_obligations:
                sw_shadow_reserve = 2000.0

        claimed_structures = {}
        for animal, k_anim in sorted(intents.get("buy_animal", {}).items()):
            k_anim = int(k_anim)
            if k_anim > 0 and animal in ANIMALS:
                struct_type = ANIMALS[animal]["structure"]
                pending_structures = int(intents.get("pending_structures", {}).get(struct_type, 0))
                def _tile_free(t):
                    t_kind = t.get("kind") if isinstance(t, dict) else getattr(t, "kind", "")
                    t_anim = t.get("is_animal") if isinstance(t, dict) else getattr(t, "is_animal", False)
                    if t_kind != struct_type or t_anim:
                        return False
                    if hasattr(farm, "unlocked") and hasattr(farm, "quadrant_of"):
                        t_pos = tuple(t.get("pos")) if isinstance(t, dict) else tuple(t.pos)
                        return farm.quadrant_of(t_pos) in farm.unlocked
                    return True

                free_structures = sum(1 for t in farm.iter_tiles() if _tile_free(t)) + pending_structures
                matching_animals = [a for a, info in ANIMALS.items() if info["structure"] == struct_type]
                animals_in_shed = sum(int(ctx["private"].shed.get(a, 0)) for a in matching_animals) if ctx.get("private") else 0
                claimed = claimed_structures.get(struct_type, 0)
                max_buyable = max(0, free_structures - animals_in_shed - claimed)
                room_limited = min(k_anim, max_buyable, remaining_shed_room)
                if room_limited <= 0:
                    ledger["dropped"].append({
                        "kind": "animal",
                        "animal": animal,
                        "reason": "shed_full" if remaining_shed_room <= 0 else "no_empty_structure",
                    })
                    continue

                unit = ANIMALS[animal]["cost"]
                animal_discretionary = max(0.0, remaining_discretionary - sw_shadow_reserve)
                n_max = int(animal_discretionary // unit)
                actual_buy = min(room_limited, n_max)
                if actual_buy < room_limited and sw_shadow_reserve > 0:
                    discretionary_livestock_suppressed = True
                if actual_buy > 0:
                    claimed_structures[struct_type] = claimed + actual_buy
                    remaining_shed_room = max(0, remaining_shed_room - actual_buy)
                    kept.append((TIER_ANIMALS, "animal", {"animal": animal, "n": actual_buy}, float(unit * actual_buy)))
                    remaining_discretionary -= unit * actual_buy
                    if actual_buy < room_limited:
                        ledger["dropped"].append({
                            "kind": "animal", "animal": animal,
                            "trimmed_from": room_limited, "to": actual_buy,
                            "reason": "sw_capital_protected" if sw_shadow_reserve > 0 else "budget",
                        })
                else:
                    ledger["dropped"].append({
                        "kind": "animal", "animal": animal,
                        "reason": "sw_capital_protected" if (sw_shadow_reserve > 0 and int(remaining_discretionary // unit) > 0) else "budget"
                    })

        ledger["discretionary_livestock_suppressed_for_sw"] = discretionary_livestock_suppressed

        # ---- emit engine-format orders, honoring optional max_slots cap -----
        orders = []
        queued = {"hire": 0, "seed": {}, "animal": {}, "wheat": 0, "land": False}
        slots = max_slots

        def take(slot_item):
            nonlocal slots
            if slots is not None:
                if slots <= 0:
                    return False
                slots -= 1
            return True

        spent = mandatory_hire_budget + survival_feed_budget + (discretionary_budget - remaining_discretionary)

        # Determine slot budget for hires at hour 0.
        # If slots is constrained, reserve slots for non-hire items in kept (wheat, land, seeds)
        # so crucial capital expansion and planting orders are not starved by excess hires.
        if slots is not None:
            non_hire_slots_needed = sum(1 for t in kept if t[1] in ("wheat", "wheat_protected", "wheat_optional", "land", "seed"))
            max_hire_slots = max(MIN_HANDS_BASE, slots - non_hire_slots_needed)
        else:
            max_hire_slots = None

        order_metadata = []
        for tier, kind, payload, est in sorted(kept, key=lambda t: t[0]):
            if kind == "hire":
                emitted = 0
                while (payload["count"] - emitted > 0 and
                       (slots is None or slots > 0) and
                       (max_hire_slots is None or emitted < max_hire_slots)):
                    orders.append(["HIRE"])
                    order_metadata.append({"kind": "hire", "tier": tier, "feed_class": None})
                    if slots is not None:
                        slots -= 1
                    emitted += 1
                queued["hire"] = emitted
                if emitted < payload["count"]:
                    dropped_cnt = payload["count"] - emitted
                    ledger["dropped"].append({
                        "kind": "hire_slots",
                        "count": dropped_cnt,
                        "cost": float(est),
                        "tier": tier,
                    })
            elif kind in ("wheat", "wheat_protected", "wheat_optional"):
                if take(None):
                    feed_class = "protected" if (kind == "wheat_protected" or payload.get("feed_class") == "protected" or payload.get("is_protected", False)) else "optional"
                    is_prot = (feed_class == "protected")
                    sem_kind = "wheat_protected" if is_prot else "wheat_optional"
                    order_metadata.append({
                        "kind": sem_kind,
                        "feed_class": feed_class,
                        "is_protected": is_prot,
                        "tier": tier,
                        "n": int(payload["n"]),
                    })
                    orders.append(["BUY_PRODUCT", "WHEAT", int(payload["n"])])
                    queued["wheat"] = int(queued.get("wheat", 0)) + int(payload["n"])
                else:
                    ledger["dropped"].append({
                        "kind": f"{kind}_slots",
                        "n": int(payload["n"]),
                        "cost": float(est),
                        "tier": tier,
                    })
            elif kind == "land":
                next_quadrant = len(farm.unlocked) + 1
                assert next_quadrant != 4, "Quadrant 4 (SE) is permanently hard-blocked and must NEVER be purchased!"
                if take(None):
                    orders.append(["BUY_LAND"])
                    order_metadata.append({"kind": "land", "tier": tier, "feed_class": None})
                    queued["land"] = True
                else:
                    ledger["dropped"].append({
                        "kind": "land_slots",
                        "cost": float(est),
                        "tier": tier,
                    })
            elif kind == "seed":
                if take(None):
                    orders.append(["BUY_SEED", payload["crop"], int(payload["n"])])
                    order_metadata.append({"kind": "seed", "crop": payload["crop"], "tier": tier, "n": int(payload["n"]), "feed_class": None})
                    queued["seed"][payload["crop"]] = int(payload["n"])
                else:
                    ledger["dropped"].append({
                        "kind": "seed_slots",
                        "crop": payload["crop"],
                        "n": int(payload["n"]),
                        "cost": float(est),
                        "tier": tier,
                    })
            elif kind == "animal":
                if take(None):
                    orders.append(["BUY_ANIMAL", payload["animal"], int(payload["n"])])
                    order_metadata.append({"kind": "animal", "animal": payload["animal"], "tier": tier, "n": int(payload["n"]), "feed_class": None})
                    queued["animal"][payload["animal"]] = int(payload["n"])
                else:
                    ledger["dropped"].append({
                        "kind": "animal_slots",
                        "animal": payload["animal"],
                        "n": int(payload["n"]),
                        "cost": float(est),
                        "tier": tier,
                    })

        ledger["queued"] = queued
        ledger["orders"] = [list(o) for o in orders]
        ledger["order_metadata"] = order_metadata
        ledger["spent_estimate"] = round(spent, 2)
        ledger["upstream_slots_limited"] = any(d.get("kind", "").endswith("_slots") for d in ledger["dropped"])
        return orders, ledger


def math_ceil(x):
    import math
    return int(math.ceil(x))


def land_price_for(unlocked_count):
    """Price of the NEXT quadrant given number of unlocked quadrants."""
    n_extra = unlocked_count - 1
    if n_extra >= len(LAND_ORDER):
        return None
    return LAND_PRICES[n_extra]


if __name__ == "__main__":
    print("module provides OrderBuilder; see tests for usage")
