"""Forward Dynamic Herd Infrastructure Planner.

Decouples forward infrastructure planning (housing demand) from live purchase execution:
  1. Forward Infrastructure Horizon: Computes `DynamicHerdPlan` projecting economically justified
     herd size over the next 3-6 days via a transactional shadow simulation.
  2. Generic Housing Demand Interface: Exposes `get_forward_housing_demand()` so `pasture_planner`
     and `macro_planner` proactively reserve and construct structures without depending on static targets.
  3. Strict Safety Preservation: Dynamic/planned housing gives ZERO credit for selective late-purchases
     after Day 12; live purchase execution independently re-evaluates economics at order time.
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional, Tuple

from config import (
    ANIMALS,
    MARKET_I0,
    C4_LIVESTOCK_CUTOFF_DAY,
    SELECTIVE_LIVESTOCK_GATE_ENABLED,
    SELECTIVE_LIVESTOCK_GATE_THRESHOLD,
    SELECTIVE_LIVESTOCK_MAX_DAY,
    get_active_livestock_caps,
)
from strategy.marginal_livestock_valuator import (
    estimate_realized_marginal_animal_value,
    select_guarded_livestock_candidate,
)


class DynamicHerdPlan:
    """Encapsulates the forward-looking economically justified herd and infrastructure requirements."""

    def __init__(
        self,
        desired_herd: Dict[str, int],
        required_pastures: int,
        required_coops: int,
        marginal_value_sequence: List[str],
        decision_records: List[Dict[str, Any]],
        horizon_days: int = 4,
        rationale: str = "",
        buy_animal_sequence: Optional[List[str]] = None,
        buy_animal: Optional[Dict[str, int]] = None,
        provisional_candidates: Optional[List[Dict[str, Any]]] = None,
        pre_ne_diagnostics: Optional[Dict[str, Any]] = None,
    ):
        self.desired_herd = dict(desired_herd)
        self.desired_cows = int(desired_herd.get("COW", 0))
        self.desired_sheep = int(desired_herd.get("SHEEP", 0))
        self.desired_geese = int(desired_herd.get("GOOSE", 0))
        self.required_pastures = int(required_pastures)
        self.required_coops = int(required_coops)
        self.marginal_value_sequence = list(marginal_value_sequence)
        self.decision_records = list(decision_records)
        self.horizon_days = int(horizon_days)
        self.rationale = str(rationale)
        self.pre_ne_diagnostics = dict(pre_ne_diagnostics) if pre_ne_diagnostics else {}

        if buy_animal_sequence is not None:
            self.buy_animal_sequence = list(buy_animal_sequence)
        else:
            self.buy_animal_sequence = [
                rec["species"] for rec in self.decision_records
                if rec.get("accepted", False) and rec.get("species") not in (None, "NONE")
            ]

        if buy_animal is not None:
            self.buy_animal = dict(buy_animal)
        else:
            self.buy_animal = {
                "COW": self.buy_animal_sequence.count("COW"),
                "SHEEP": self.buy_animal_sequence.count("SHEEP"),
                "GOOSE": self.buy_animal_sequence.count("GOOSE"),
            }

        if provisional_candidates is not None:
            self.provisional_candidates = list(provisional_candidates)
        else:
            self.provisional_candidates = []
            seq_counter = 0
            rej_counter = 0
            for rec in self.decision_records:
                is_accepted = bool(rec.get("accepted", False))
                sp = rec.get("species", "NONE")
                if is_accepted:
                    c_id = rec.get("candidate_id") or f"cand_{seq_counter}_{sp}"
                    s_idx = rec.get("sequence_index", seq_counter)
                    seq_counter += 1
                    status = "admitted"
                    exec_status = rec.get("execution_status", "admitted")
                else:
                    c_id = rec.get("candidate_id") or f"cand_rej_{rej_counter}_{sp}"
                    s_idx = rec.get("sequence_index", -1)
                    rej_counter += 1
                    status = rec.get("provisional_status", "rejected")
                    exec_status = rec.get("execution_status", "rejected")

                feed_diag = rec.get("feed_diagnostics") or rec.get("feed_feasibility") or rec.get("feasibility_diag") or {}
                self.provisional_candidates.append({
                    "candidate_id": c_id,
                    "sequence_index": s_idx,
                    "species": sp,
                    "provisional_status": status,
                    "feed_feasible": bool(rec.get("feed_feasible", is_accepted)),
                    "execution_status": exec_status,
                    "net_realized_value": float(rec.get("net_val", 0.0)),
                    "reason": str(rec.get("reason", "economically_justified" if is_accepted else "rejected")),
                    "feed_diagnostics": feed_diag,
                })

    def to_dict(self) -> Dict[str, Any]:
        return {
            "desired_herd": self.desired_herd,
            "desired_cows": self.desired_cows,
            "desired_sheep": self.desired_sheep,
            "desired_geese": self.desired_geese,
            "required_pastures": self.required_pastures,
            "required_coops": self.required_coops,
            "horizon_days": self.horizon_days,
            "marginal_value_sequence": self.marginal_value_sequence,
            "rationale": self.rationale,
            "buy_animal_sequence": list(self.buy_animal_sequence),
            "buy_animal": dict(self.buy_animal),
            "provisional_candidates": list(self.provisional_candidates),
            "pre_ne_diagnostics": dict(self.pre_ne_diagnostics),
        }

    def __repr__(self) -> str:
        return (
            f"DynamicHerdPlan(cows={self.desired_cows}, sheep={self.desired_sheep}, geese={self.desired_geese}, "
            f"req_pastures={self.required_pastures}, req_coops={self.required_coops}, horizon={self.horizon_days}d)"
        )


def generate_dynamic_herd_plan(
    day: int,
    hour: int,
    current_herd: Dict[str, int],
    town_shops: Optional[List[str]] = None,
    market_inventory: Optional[Dict[str, float]] = None,
    max_sustainable: Optional[int] = None,
    active_caps: Optional[Dict[str, int]] = None,
    crop_opportunity_val: float = 0.0,
    horizon_days: int = 4,
    opponent_committed_supplies: Optional[Dict[str, Dict[int, float]]] = None,
    opponent_stress_supplies: Optional[Dict[str, Dict[int, float]]] = None,
    guard_threshold: float = 0.15,
    feed_ledger: Optional[Any] = None,
    late_selective_mode: bool = False,
    physical_housing_capacity: Optional[Dict[str, int]] = None,
    allow_late_continuation: bool = False,
    pre_ne_capital_mode: Optional[str] = None,
    ne_locked: Optional[bool] = None,
    pre_ne_livestock_envelope: Optional[float] = None,
) -> DynamicHerdPlan:
    """Generate forward infrastructure herd targets using transactional shadow-state economics.

    Simulates adding prospective animals one by one into a shadow herd:
      - At each step, evaluates marginal counterfactual net value for COW, SHEEP, GOOSE.
      - If feed_ledger is provided (Phase B authority):
          * Baseline existing herd must be feed-feasible; if not, stops immediately.
          * Candidates are filtered by incremental feed feasibility against residual ledger.
          * Selected candidate reservations are committed to feed_ledger.
          * Does not clamp target_cap by legacy scalar max_sustainable.
      - If feed_ledger is None:
          * Preserves legacy scalar max_sustainable cap behavior.
      - Picks the argmax profitable species.
      - Updates shadow herd, shadow future supply, shadow feed demand, and required housing.
      - Stops when no candidate clears the economic hurdle or constraints (caps, feed sustainability) bind.
      - Phase C2B: When late_selective_mode=True and day in [12, 14], restricts candidates to observed
        physical housing only, applies SELECTIVE_LIVESTOCK_GATE_THRESHOLD ($500 hurdle), and generates
        the authoritative late-selective candidate sequence.
      - Pre-NE Capital Admission Policy: When pre_ne_capital_mode in ("ne_first", "ne_escrow") and ne_locked=True,
        restricts candidate admission to protect NE acquisition capital.
    """
    day = int(day)
    caps = active_caps or get_active_livestock_caps()
    herd_cap = caps.get("HERD", 20)
    cow_cap = caps.get("COW", 19)
    sheep_cap = caps.get("SHEEP", 12)

    c0 = max(0, int(current_herd.get("COW", 0)))
    s0 = max(0, int(current_herd.get("SHEEP", 0)))
    g0 = max(0, int(current_herd.get("GOOSE", 0)))

    try:
        from config import get_point2_pre_ne_capital_mode
        cfg_pre_ne_mode = get_point2_pre_ne_capital_mode()
    except Exception:
        cfg_pre_ne_mode = "off"

    eff_pre_ne_mode = pre_ne_capital_mode if pre_ne_capital_mode is not None else cfg_pre_ne_mode
    is_ne_locked = bool(ne_locked) if ne_locked is not None else False

    if not is_ne_locked or eff_pre_ne_mode == "off":
        envelope_before = float('inf')
    elif eff_pre_ne_mode == "ne_first":
        envelope_before = 0.0
    else:  # ne_escrow
        envelope_before = float(pre_ne_livestock_envelope) if pre_ne_livestock_envelope is not None else 0.0

    rem_envelope = envelope_before
    pre_ne_diag_records: List[Dict[str, Any]] = []

    # On or after Day 12 cutoff: new infrastructure cannot amortize construction cost
    # Unless late_selective_mode is active (live mode only, Day 12-14, physical housing only)
    if day >= C4_LIVESTOCK_CUTOFF_DAY:
        if not (late_selective_mode and day <= SELECTIVE_LIVESTOCK_MAX_DAY):
            return DynamicHerdPlan(
                desired_herd={"COW": c0, "SHEEP": s0, "GOOSE": 0},
                required_pastures=c0 + s0,
                required_coops=g0,
                marginal_value_sequence=[f"Day {day} >= cutoff ({C4_LIVESTOCK_CUTOFF_DAY}) -> 0 new forward housing"],
                decision_records=[],
                horizon_days=horizon_days,
                rationale="late_season_cutoff",
                pre_ne_diagnostics={
                    "mode": eff_pre_ne_mode,
                    "ne_locked": is_ne_locked,
                    "envelope_before": envelope_before,
                    "envelope_remaining": rem_envelope,
                    "candidates": [],
                },
            )

    # Initialize transactional shadow state
    shadow_herd = {"COW": c0, "SHEEP": s0, "GOOSE": 0}
    marginal_value_seq: List[str] = []
    decision_records: List[Dict[str, Any]] = []
    buy_animal_seq: List[str] = []

    if feed_ledger is not None:
        try:
            from strategy.feed_feasibility import (
                evaluate_existing_herd_feasibility,
                evaluate_incremental_candidate,
                commit_candidate_reservation,
            )
        except ImportError:
            from feed_feasibility import (
                evaluate_existing_herd_feasibility,
                evaluate_incremental_candidate,
                commit_candidate_reservation,
            )

        existing_ok, existing_res = evaluate_existing_herd_feasibility(feed_ledger)
        if not existing_ok:
            return DynamicHerdPlan(
                desired_herd=dict(shadow_herd),
                required_pastures=c0 + s0,
                required_coops=g0,
                marginal_value_sequence=[
                    f"Baseline existing herd infeasible ({existing_res.blocking_reason}) -> STOP"
                ],
                decision_records=[{
                    "candidate_id": "cand_rej_0_NONE",
                    "sequence_index": -1,
                    "species": "NONE",
                    "candidate_num": 0,
                    "net_val": 0.0,
                    "accepted": False,
                    "provisional_status": "rejected",
                    "feed_feasible": False,
                    "execution_status": "rejected",
                    "reason": f"baseline_existing_herd_infeasible: {existing_res.blocking_reason}",
                    "feed_diagnostics": existing_res.to_dict(),
                    "feasibility_diag": existing_res.to_dict(),
                }],
                horizon_days=horizon_days,
                rationale="baseline_existing_herd_infeasible",
                buy_animal_sequence=[],
                buy_animal={"COW": 0, "SHEEP": 0, "GOOSE": 0},
                pre_ne_diagnostics={
                    "mode": eff_pre_ne_mode,
                    "ne_locked": is_ne_locked,
                    "envelope_before": envelope_before,
                    "envelope_remaining": rem_envelope,
                    "candidates": [],
                },
            )
        target_cap = herd_cap
    else:
        eff_max_sustainable = max_sustainable if max_sustainable is not None else herd_cap
        target_cap = min(herd_cap, eff_max_sustainable)

    # Infrastructure build cost allowance:
    # Under late selective mode: candidates must clear $500 hurdle and use physical housing only
    if late_selective_mode and day >= C4_LIVESTOCK_CUTOFF_DAY:
        avail_pastures = max(0, int(physical_housing_capacity.get("PASTURE", 0))) if physical_housing_capacity else 0
        avail_coops = max(0, int(physical_housing_capacity.get("COOP", 0))) if physical_housing_capacity else 0
        target_cap = (c0 + s0 + g0) + avail_pastures + avail_coops
        if allow_late_continuation and day in (12, 13) and avail_pastures == 0:
            target_cap += 1  # Exactly 1 forward continuation pasture candidate
        housing_build_hurdle = float(SELECTIVE_LIVESTOCK_GATE_THRESHOLD)
    else:
        avail_pastures = 999
        avail_coops = 999
        housing_build_hurdle = 150.0

    try:
        from config import BOOTSTRAP_LIVESTOCK_ARM, get_bootstrap_target_sequence
    except Exception:
        BOOTSTRAP_LIVESTOCK_ARM = "none"
        get_bootstrap_target_sequence = lambda arm=None: []

    is_bootstrap_active = bool(day == 0 and BOOTSTRAP_LIVESTOCK_ARM not in ("none", "", None))
    if is_bootstrap_active:
        bootstrap_target_seq = get_bootstrap_target_sequence(BOOTSTRAP_LIVESTOCK_ARM)
        for cand_idx, species in enumerate(bootstrap_target_seq):
            cand_res = None
            cand_feasible = True
            if feed_ledger is not None:
                cand_res = evaluate_incremental_candidate(
                    feed_ledger, species, is_day0_bootstrap=True
                )
                cand_feasible = cand_res.feasible

            if not cand_feasible:
                f_reason = cand_res.blocking_reason if cand_res else "feed_infeasible"
                marginal_value_seq.append(
                    f"Bootstrap {species} #{cand_idx+1}: REJECTED ({f_reason}) -> STOP"
                )
                cand_diag = cand_res.to_dict() if cand_res else {}
                decision_records.append({
                    "candidate_id": f"cand_rej_bootstrap_{cand_idx}_{species}",
                    "sequence_index": -1,
                    "species": species,
                    "candidate_num": shadow_herd.get(species, 0) + 1,
                    "net_val": 0.0,
                    "accepted": False,
                    "provisional_status": "rejected",
                    "feed_feasible": False,
                    "execution_status": "rejected",
                    "reason": f"bootstrap_feed_infeasible_{f_reason}",
                    "feed_diagnostics": cand_diag,
                    "feed_feasibility": cand_diag,
                })
                break

            eval_base = estimate_realized_marginal_animal_value(
                species=species,
                day=day,
                current_animals=shadow_herd,
                market_inventory=market_inventory,
                empty_pastures=1,
                crop_opportunity_val=crop_opportunity_val,
                town_shops=town_shops,
                opponent_committed_supply=(opponent_committed_supplies.get("MILK" if species == "COW" else ("WOOL" if species == "SHEEP" else "EGG")) if opponent_committed_supplies else None),
            )
            val = eval_base.get("net_realized_value", 0.0)

            # Stage 2: Displaced crop economic opportunity cost check for 3rd/4th animal
            displaced_melons = 0
            if cand_idx == 2:  # 3rd animal (Sheep #1 in Arm C/D, Cow #3 in Arm E)
                if species == "SHEEP":
                    displaced_melons = 8  # Displaces 8 melons ($640 seed cost)
                elif species == "COW":
                    displaced_melons = 6  # Displaces 6 melons ($480 seed cost)
            elif cand_idx >= 3:
                displaced_melons = 0

            # Displaced crop opportunity: lost Cycle 1 melon net margin ($55/melon)
            displaced_crop_value = displaced_melons * 55.0
            net_advantage = val - displaced_crop_value

            if net_advantage < housing_build_hurdle:
                marginal_value_seq.append(
                    f"Bootstrap {species} #{cand_idx+1}: net advantage ${net_advantage:.0f} (val ${val:.0f} - crop loss ${displaced_crop_value:.0f}) -> STOP"
                )
                cand_diag = cand_res.to_dict() if cand_res else {}
                decision_records.append({
                    "candidate_id": f"cand_rej_bootstrap_{cand_idx}_{species}",
                    "sequence_index": -1,
                    "species": species,
                    "candidate_num": shadow_herd.get(species, 0) + 1,
                    "net_val": round(net_advantage, 2),
                    "accepted": False,
                    "provisional_status": "rejected",
                    "feed_feasible": True,
                    "execution_status": "rejected",
                    "reason": "below_crop_tradeoff_hurdle",
                    "displaced_crop_investment": f"{displaced_melons} MELON",
                    "displaced_crop_value": displaced_crop_value,
                    "feed_diagnostics": cand_diag,
                    "feed_feasibility": cand_diag,
                })
                break

            # Pre-NE Capital Admission Policy Check
            cand_incremental_feed = float(
                cand_res.diagnostics.get("delta_total_feed", 0.0)
                if (cand_res is not None and getattr(cand_res, "diagnostics", None))
                else 0.0
            )
            cand_purchase_cost = float(ANIMALS.get(species, {}).get("cost", 400.0))
            cand_package_cost = cand_purchase_cost + cand_incremental_feed
            cand_deferred = False
            if is_ne_locked and eff_pre_ne_mode in ("ne_first", "ne_escrow"):
                if eff_pre_ne_mode == "ne_first":
                    cand_deferred = True
                elif eff_pre_ne_mode == "ne_escrow":
                    if cand_package_cost > rem_envelope:
                        cand_deferred = True

            if cand_deferred:
                cand_diag = cand_res.to_dict() if cand_res else {}
                pre_ne_diag_records.append({
                    "species": species,
                    "candidate_id": f"cand_rej_bootstrap_{cand_idx}_{species}",
                    "admitted": False,
                    "reason": "ne_capital_deferred",
                    "package_cost": cand_package_cost,
                    "envelope_before": rem_envelope,
                    "envelope_after": rem_envelope,
                })
                decision_records.append({
                    "candidate_id": f"cand_rej_bootstrap_{cand_idx}_{species}",
                    "sequence_index": -1,
                    "species": species,
                    "candidate_num": shadow_herd.get(species, 0) + 1,
                    "net_val": round(net_advantage, 2),
                    "accepted": False,
                    "provisional_status": "rejected",
                    "feed_feasible": True,
                    "execution_status": "rejected",
                    "reason": "ne_capital_deferred",
                    "rejection_reason": "ne_capital_deferred",
                    "displaced_crop_investment": f"{displaced_melons} MELON",
                    "displaced_crop_value": displaced_crop_value,
                    "feed_diagnostics": cand_diag,
                    "feed_feasibility": cand_diag,
                })
                marginal_value_seq.append(
                    f"Bootstrap {species} #{cand_idx+1}: DEFERRED by Pre-NE policy ({eff_pre_ne_mode}, cost ${cand_package_cost:.0f} > rem ${rem_envelope:.0f}) -> STOP"
                )
                break

            if is_ne_locked and eff_pre_ne_mode == "ne_escrow":
                rem_envelope -= cand_package_cost

            if feed_ledger is not None and cand_res is not None:
                commit_candidate_reservation(feed_ledger, cand_res)

            shadow_herd[species] = shadow_herd.get(species, 0) + 1
            seq_idx = len(buy_animal_seq)
            buy_animal_seq.append(species)
            pre_ne_diag_records.append({
                "species": species,
                "candidate_id": f"cand_bootstrap_{seq_idx}_{species}",
                "admitted": True,
                "reason": "admitted",
                "package_cost": cand_package_cost,
                "envelope_before": rem_envelope + cand_package_cost if is_ne_locked and eff_pre_ne_mode == "ne_escrow" else envelope_before,
                "envelope_after": rem_envelope,
            })
            marginal_value_seq.append(f"Bootstrap {species} #{shadow_herd[species]}: +${val:.0f} (net advantage +${net_advantage:.0f})")
            feed_diag = cand_res.to_dict() if cand_res else {}
            decision_records.append({
                "candidate_id": f"cand_bootstrap_{seq_idx}_{species}",
                "sequence_index": seq_idx,
                "species": species,
                "candidate_num": shadow_herd[species],
                "net_val": round(val, 2),
                "displaced_crop_investment": f"{displaced_melons} MELON",
                "displaced_crop_value": displaced_crop_value,
                "net_allocation_advantage": round(net_advantage, 2),
                "accepted": True,
                "provisional_status": "admitted",
                "feed_feasible": True,
                "reason": "bootstrap_cohort_admitted",
                "execution_status": "admitted",
                "feed_diagnostics": feed_diag,
                "feed_feasibility": feed_diag,
            })

        req_pastures = shadow_herd["COW"] + shadow_herd["SHEEP"]
        req_coops = shadow_herd["GOOSE"]

        return DynamicHerdPlan(
            desired_herd=shadow_herd,
            required_pastures=req_pastures,
            required_coops=req_coops,
            marginal_value_sequence=marginal_value_seq,
            decision_records=decision_records,
            horizon_days=horizon_days,
            rationale=f"bootstrap_{BOOTSTRAP_LIVESTOCK_ARM}_c{shadow_herd['COW']}_s{shadow_herd['SHEEP']}_g{shadow_herd['GOOSE']}",
            buy_animal_sequence=buy_animal_seq,
            pre_ne_diagnostics={
                "mode": eff_pre_ne_mode,
                "ne_locked": is_ne_locked,
                "envelope_before": envelope_before,
                "envelope_remaining": rem_envelope,
                "candidates": pre_ne_diag_records,
            },
        )

    while sum(shadow_herd.values()) < target_cap:
        curr_total = sum(shadow_herd.values())
        base_evals: Dict[str, Dict[str, Any]] = {}
        stress_evals: Dict[str, Dict[str, Any]] = {}
        cand_results: Dict[str, Any] = {}
        infeasible_feed_cands: Dict[str, Any] = {}

        pastures_used = (shadow_herd["COW"] - c0) + (shadow_herd["SHEEP"] - s0)
        coops_used = shadow_herd["GOOSE"] - g0

        is_continuation_pasture_eval = bool(
            late_selective_mode
            and day >= C4_LIVESTOCK_CUTOFF_DAY
            and allow_late_continuation
            and day in (12, 13)
            and pastures_used >= avail_pastures
        )
        empty_pastures_eval = 0 if is_continuation_pasture_eval else 1

        # 1. Evaluate COW
        cow_housing_ok = (
            not late_selective_mode
            or day < C4_LIVESTOCK_CUTOFF_DAY
            or pastures_used < avail_pastures
            or (allow_late_continuation and day in (12, 13) and pastures_used < (avail_pastures + 1))
        )
        if shadow_herd["COW"] < cow_cap and (curr_total + 1) <= target_cap and cow_housing_ok:
            cand_feasible = True
            cand_res = None
            if feed_ledger is not None:
                cand_res = evaluate_incremental_candidate(feed_ledger, "COW")
                cand_feasible = cand_res.feasible
                if not cand_feasible:
                    infeasible_feed_cands["COW"] = cand_res

            if cand_feasible:
                eval_c_base = estimate_realized_marginal_animal_value(
                    species="COW",
                    day=day,
                    current_animals=shadow_herd,
                    market_inventory=market_inventory,
                    empty_pastures=empty_pastures_eval,
                    crop_opportunity_val=crop_opportunity_val,
                    town_shops=town_shops,
                    opponent_committed_supply=(opponent_committed_supplies.get("MILK") if opponent_committed_supplies else None),
                )
                base_evals["COW"] = eval_c_base
                if cand_res is not None:
                    cand_results["COW"] = cand_res
                if opponent_stress_supplies is not None:
                    eval_c_stress = estimate_realized_marginal_animal_value(
                        species="COW",
                        day=day,
                        current_animals=shadow_herd,
                        market_inventory=market_inventory,
                        empty_pastures=empty_pastures_eval,
                        crop_opportunity_val=crop_opportunity_val,
                        town_shops=town_shops,
                        opponent_committed_supply=opponent_stress_supplies.get("MILK"),
                    )
                    stress_evals["COW"] = eval_c_stress

        # 2. Evaluate SHEEP
        sheep_housing_ok = (
            not late_selective_mode
            or day < C4_LIVESTOCK_CUTOFF_DAY
            or pastures_used < avail_pastures
            or (allow_late_continuation and day in (12, 13) and pastures_used < (avail_pastures + 1))
        )
        if shadow_herd["SHEEP"] < sheep_cap and (curr_total + 1) <= target_cap and sheep_housing_ok:
            cand_feasible = True
            cand_res = None
            if feed_ledger is not None:
                cand_res = evaluate_incremental_candidate(feed_ledger, "SHEEP")
                cand_feasible = cand_res.feasible
                if not cand_feasible:
                    infeasible_feed_cands["SHEEP"] = cand_res

            if cand_feasible:
                eval_s_base = estimate_realized_marginal_animal_value(
                    species="SHEEP",
                    day=day,
                    current_animals=shadow_herd,
                    market_inventory=market_inventory,
                    empty_pastures=empty_pastures_eval,
                    crop_opportunity_val=crop_opportunity_val,
                    town_shops=town_shops,
                    opponent_committed_supply=(opponent_committed_supplies.get("WOOL") if opponent_committed_supplies else None),
                )
                base_evals["SHEEP"] = eval_s_base
                if cand_res is not None:
                    cand_results["SHEEP"] = cand_res
                if opponent_stress_supplies is not None:
                    eval_s_stress = estimate_realized_marginal_animal_value(
                        species="SHEEP",
                        day=day,
                        current_animals=shadow_herd,
                        market_inventory=market_inventory,
                        empty_pastures=empty_pastures_eval,
                        crop_opportunity_val=crop_opportunity_val,
                        town_shops=town_shops,
                        opponent_committed_supply=opponent_stress_supplies.get("WOOL"),
                    )
                    stress_evals["SHEEP"] = eval_s_stress

        # 3. Evaluate GOOSE (strict zero-geese check: evaluate real ROI)
        goose_housing_ok = (not late_selective_mode or day < C4_LIVESTOCK_CUTOFF_DAY or coops_used < avail_coops)
        if (curr_total + 1) <= target_cap and goose_housing_ok:
            cand_feasible = True
            cand_res = None
            if feed_ledger is not None:
                cand_res = evaluate_incremental_candidate(feed_ledger, "GOOSE")
                cand_feasible = cand_res.feasible
                if not cand_feasible:
                    infeasible_feed_cands["GOOSE"] = cand_res

            if cand_feasible:
                eval_g_base = estimate_realized_marginal_animal_value(
                    species="GOOSE",
                    day=day,
                    current_animals=shadow_herd,
                    market_inventory=market_inventory,
                    empty_pastures=1,
                    crop_opportunity_val=crop_opportunity_val,
                    town_shops=town_shops,
                    opponent_committed_supply=(opponent_committed_supplies.get("EGG") if opponent_committed_supplies else None),
                )
                base_evals["GOOSE"] = eval_g_base
                if cand_res is not None:
                    cand_results["GOOSE"] = cand_res
                if opponent_stress_supplies is not None:
                    eval_g_stress = estimate_realized_marginal_animal_value(
                        species="GOOSE",
                        day=day,
                        current_animals=shadow_herd,
                        market_inventory=market_inventory,
                        empty_pastures=1,
                        crop_opportunity_val=crop_opportunity_val,
                        town_shops=town_shops,
                        opponent_committed_supply=opponent_stress_supplies.get("EGG"),
                    )
                    stress_evals["GOOSE"] = eval_g_stress

        if not base_evals:
            if feed_ledger is not None and (curr_total < target_cap):
                marginal_value_seq.append("No candidates feasible under FeedResourceLedger -> STOP")
                for sp in ("COW", "SHEEP", "GOOSE"):
                    cand_res = infeasible_feed_cands.get(sp)
                    if cand_res is not None:
                        decision_records.append({
                            "candidate_id": f"cand_rej_{len(decision_records)}_{sp}",
                            "sequence_index": -1,
                            "species": sp,
                            "candidate_num": shadow_herd[sp] + 1,
                            "net_val": 0.0,
                            "accepted": False,
                            "provisional_status": "rejected",
                            "feed_feasible": False,
                            "execution_status": "rejected",
                            "reason": f"feed_infeasible: {cand_res.blocking_reason}",
                            "feed_diagnostics": cand_res.to_dict(),
                            "feed_feasibility": cand_res.to_dict(),
                        })
            break

        # Select candidate: guarded commitment awareness if stress test provided, otherwise argmax baseline
        if opponent_stress_supplies is not None:
            best_sp, chosen_eval, diag = select_guarded_livestock_candidate(
                base_evals, stress_evals, guard_threshold=guard_threshold
            )
            best_val = chosen_eval["net_realized_value"]
        else:
            best_sp = max(base_evals.keys(), key=lambda sp: base_evals[sp]["net_realized_value"])
            chosen_eval = base_evals[best_sp]
            best_val = chosen_eval["net_realized_value"]
            diag = {"switched": False}

        next_count = shadow_herd[best_sp] + 1

        # Check hurdle: must cover capital costs and prospective housing
        if best_val < housing_build_hurdle:
            marginal_value_seq.append(
                f"{best_sp} #{next_count}: ${best_val:.0f} -> STOP (below hurdle ${housing_build_hurdle:.0f})"
            )
            cand_diag = cand_results[best_sp].to_dict() if (best_sp in cand_results and cand_results[best_sp]) else {}
            decision_records.append({
                "candidate_id": f"cand_rej_{len(decision_records)}_{best_sp}",
                "sequence_index": -1,
                "species": best_sp,
                "candidate_num": next_count,
                "net_val": round(best_val, 2),
                "accepted": False,
                "provisional_status": "rejected",
                "feed_feasible": True,
                "execution_status": "rejected",
                "reason": "below_housing_hurdle" if not late_selective_mode else "below_selective_hurdle",
                "feed_diagnostics": cand_diag,
                "feed_feasibility": cand_diag,
            })
            break

        # Pre-NE Capital Admission Policy Check
        best_cand_res = cand_results.get(best_sp) if (feed_ledger is not None and best_sp in cand_results) else None
        cand_incremental_feed = float(
            best_cand_res.diagnostics.get("delta_total_feed", 0.0)
            if (best_cand_res is not None and getattr(best_cand_res, "diagnostics", None))
            else 0.0
        )
        cand_purchase_cost = float(ANIMALS.get(best_sp, {}).get("cost", 400.0))
        cand_package_cost = cand_purchase_cost + cand_incremental_feed
        cand_deferred = False
        if is_ne_locked and eff_pre_ne_mode in ("ne_first", "ne_escrow"):
            if eff_pre_ne_mode == "ne_first":
                cand_deferred = True
            elif eff_pre_ne_mode == "ne_escrow":
                if cand_package_cost > rem_envelope:
                    cand_deferred = True

        if cand_deferred:
            cand_diag = cand_results[best_sp].to_dict() if (best_sp in cand_results and cand_results[best_sp]) else {}
            pre_ne_diag_records.append({
                "species": best_sp,
                "candidate_id": f"cand_rej_{len(decision_records)}_{best_sp}",
                "admitted": False,
                "reason": "ne_capital_deferred",
                "package_cost": cand_package_cost,
                "envelope_before": rem_envelope,
                "envelope_after": rem_envelope,
            })
            decision_records.append({
                "candidate_id": f"cand_rej_{len(decision_records)}_{best_sp}",
                "sequence_index": -1,
                "species": best_sp,
                "candidate_num": next_count,
                "net_val": round(best_val, 2),
                "accepted": False,
                "provisional_status": "rejected",
                "feed_feasible": True,
                "execution_status": "rejected",
                "reason": "ne_capital_deferred",
                "rejection_reason": "ne_capital_deferred",
                "feed_diagnostics": cand_diag,
                "feed_feasibility": cand_diag,
            })
            marginal_value_seq.append(
                f"{best_sp} #{next_count}: DEFERRED by Pre-NE policy ({eff_pre_ne_mode}, cost ${cand_package_cost:.0f} > rem ${rem_envelope:.0f}) -> STOP"
            )
            break

        if is_ne_locked and eff_pre_ne_mode == "ne_escrow":
            rem_envelope -= cand_package_cost
            pre_ne_diag_records.append({
                "species": best_sp,
                "candidate_id": f"cand_{len(buy_animal_seq)}_{best_sp}",
                "admitted": True,
                "reason": "admitted",
                "package_cost": cand_package_cost,
                "envelope_before": rem_envelope + cand_package_cost,
                "envelope_after": rem_envelope,
            })
        elif is_ne_locked:
            pre_ne_diag_records.append({
                "species": best_sp,
                "candidate_id": f"cand_{len(buy_animal_seq)}_{best_sp}",
                "admitted": True,
                "reason": "admitted",
                "package_cost": cand_package_cost,
                "envelope_before": envelope_before,
                "envelope_after": rem_envelope,
            })

        # ACCEPT candidate into forward shadow state
        is_forward_only = bool(
            late_selective_mode
            and day >= C4_LIVESTOCK_CUTOFF_DAY
            and allow_late_continuation
            and day in (12, 13)
            and pastures_used >= avail_pastures
        )

        status = "admitted_forward_continuation" if is_forward_only else ("admitted_late_selective" if late_selective_mode else "admitted")
        feed_diag = None
        feed_hold_before = float(feed_ledger.candidate_feed_cash_hold) if feed_ledger is not None else 0.0
        shadow_feed_hold_after = feed_hold_before
        if feed_ledger is not None:
            best_cand_res = cand_results[best_sp]
            if is_forward_only:
                # Part 1 fix: clone ledger for hypothetical candidate evaluation; authoritative ledger remains 100% unmutated
                ledger_clone = feed_ledger.clone()
                commit_candidate_reservation(ledger_clone, best_cand_res)
                if best_cand_res.execution_confidence in ("guarded", "conditional"):
                    status = "provisional_guarded"
                feed_diag = best_cand_res.to_dict()
                shadow_feed_hold_after = float(ledger_clone.candidate_feed_cash_hold)
                del ledger_clone
            else:
                commit_candidate_reservation(feed_ledger, best_cand_res)
                if best_cand_res.execution_confidence in ("guarded", "conditional"):
                    status = "provisional_guarded"
                feed_diag = best_cand_res.to_dict()
                shadow_feed_hold_after = float(feed_ledger.candidate_feed_cash_hold)
        feed_hold_after = float(feed_ledger.candidate_feed_cash_hold) if feed_ledger is not None else 0.0

        if is_forward_only and feed_ledger is not None:
            try:
                from state.state_tracker import _STATE
                _STATE.setdefault("forward_only_feed_holds", []).append({
                    "day": day,
                    "hour": hour,
                    "species": best_sp,
                    "authoritative_hold_before": feed_hold_before,
                    "authoritative_hold_after": feed_hold_after,
                    "authoritative_delta": feed_hold_after - feed_hold_before,
                    "shadow_hold_after": shadow_feed_hold_after,
                    "hold_before": feed_hold_before,
                    "hold_after": feed_hold_after,
                    "delta": feed_hold_after - feed_hold_before,
                })
            except Exception:
                pass

        shadow_herd[best_sp] += 1
        seq_idx = len(buy_animal_seq)
        if not is_forward_only:
            buy_animal_seq.append(best_sp)
        switch_note = f" (SWITCH from {diag.get('baseline_best')} [gap {diag.get('relative_gap', 0):.1%}])" if diag.get("switched") else ""
        forward_note = " [FORWARD HOUSING CONTINUATION ONLY]" if is_forward_only else ""
        marginal_value_seq.append(f"{best_sp} #{next_count}: +${best_val:.0f}{switch_note}{forward_note}")
        rec = {
            "candidate_id": f"cand_{seq_idx}_{best_sp}",
            "sequence_index": seq_idx if not is_forward_only else -1,
            "species": best_sp,
            "candidate_num": next_count,
            "net_val": round(best_val, 2),
            "accepted": True,
            "provisional_status": "admitted",
            "feed_feasible": True,
            "reason": "forward_housing_continuation_justified" if is_forward_only else "economically_justified",
            "forward_only": is_forward_only,
            "purchase_eligible": not is_forward_only,
            "feed_hold_before": feed_hold_before,
            "feed_hold_after": feed_hold_after,
            "guarded_diag": diag,
            "execution_status": status,
            "feed_diagnostics": feed_diag or {},
        }
        if feed_diag is not None:
            rec["feed_feasibility"] = feed_diag
        decision_records.append(rec)

    req_pastures = shadow_herd["COW"] + shadow_herd["SHEEP"]
    req_coops = shadow_herd["GOOSE"]

    return DynamicHerdPlan(
        desired_herd=shadow_herd,
        required_pastures=req_pastures,
        required_coops=req_coops,
        marginal_value_sequence=marginal_value_seq,
        decision_records=decision_records,
        horizon_days=horizon_days,
        rationale=f"shadow_econ_plan_c{shadow_herd['COW']}_s{shadow_herd['SHEEP']}_g{shadow_herd['GOOSE']}",
        buy_animal_sequence=buy_animal_seq,
        pre_ne_diagnostics={
            "mode": eff_pre_ne_mode,
            "ne_locked": is_ne_locked,
            "envelope_before": envelope_before,
            "envelope_remaining": rem_envelope,
            "candidates": pre_ne_diag_records,
        },
    )


def get_forward_housing_demand(
    dynamic_herd_plan: DynamicHerdPlan,
    existing_pastures: int,
    reserved_pasture_tiles: int,
    existing_coops: int = 0,
    reserved_coop_tiles: int = 0,
) -> Dict[str, int]:
    """Calculate the net unreserved infrastructure demand for forward planning.

    Returns:
      {
        "needed_pastures": int,  # Net pasture fences to construct
        "needed_coops": int,     # Net coops to construct
      }
    """
    total_committed_pastures = int(existing_pastures) + int(reserved_pasture_tiles)
    needed_pastures = max(0, dynamic_herd_plan.required_pastures - total_committed_pastures)

    total_committed_coops = int(existing_coops) + int(reserved_coop_tiles)
    needed_coops = max(0, dynamic_herd_plan.required_coops - total_committed_coops)

    return {
        "needed_pastures": needed_pastures,
        "needed_coops": needed_coops,
    }
